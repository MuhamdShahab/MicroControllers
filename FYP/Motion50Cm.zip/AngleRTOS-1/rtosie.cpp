#include "rtosie.h"


const int ENCR = 35;// YELLOW-
const int ENCR1 = 34; // GREEN-
const int ENCL = 33; // YELLOW-
const int ENCL1 = 32; //GREEN-

const int RM = 13; // pwm right motor-
const int LM = 25; // pwm left motor-

// the number of the Motor Pins
const int RM1 = 12; //Right motor 1st terminal-
const int RM2 = 14;  //Right motor 2nd terminal-
const int LM1 = 27; //left motor 1st terminal-
const int LM2 = 26;  //left motor 2nd terminal-

//Motor Channel
const int RM_ch = 0; //PWM channel--timer based-
const int LM_ch = 1; //PWM channel--timer based-

// setting PWM properties
const int motors_freq = 5000; //Motor Frequency-
const int motors_res = 8; //Motor Resoltion 8 bits-


robot_motor::robot_motor(int M1,int M2,int M,int M_ch,int ENC,int ENC1)
{
    encoder = ENC;// YELLOW-
    encoder1 = ENC1; // GREEN-
    pwm_pin = M; // pwm right motor-
    pos = M1; //motor 1st terminal-
    neg = M2;  //motor 2nd terminal-
    channel = M_ch; //PWM channel--timer based-
}

void robot_motor::move_forward(int pwm)
{
    digitalWrite(pos, HIGH);
    digitalWrite(neg, LOW);
    ledcWrite(channel, pwm);
}

void robot_motor::move_backward(int pwm)
{
    digitalWrite(neg, HIGH);
    digitalWrite(pos, LOW);
    ledcWrite(channel, pwm);
}

void robot_motor::donot_move()
{
    digitalWrite(neg, LOW);
    digitalWrite(pos, LOW);
    ledcWrite(channel, 0);
}


robot_motor Right(RM1,RM2,RM,RM_ch,ENCR,ENCR1);
robot_motor Left(LM1,LM2,LM,LM_ch,ENCL,ENCL1);

int PWMR = 0;
int PWML = 0;

void motor_setup()
{
  pinMode(ENCR,INPUT_PULLUP);
  pinMode(ENCR1,INPUT_PULLUP);   
  pinMode(ENCL,INPUT_PULLUP);
  pinMode(ENCL1,INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENCR),readEncoderR,RISING);
  attachInterrupt(digitalPinToInterrupt(ENCL),readEncoderL,RISING);

  
  pinMode(RM,OUTPUT);
  pinMode(RM1,OUTPUT);
  pinMode(RM2,OUTPUT);
  pinMode(LM,OUTPUT);
  pinMode(LM1,OUTPUT);
  pinMode(LM2,OUTPUT);

  ledcSetup(RM_ch, 5000, 8);
  ledcAttachPin(RM, RM_ch);  
  ledcSetup(LM_ch, 5000, 8);
  ledcAttachPin(LM, LM_ch);
}



double PIDc_time,delta_time,PIDptime;
int PIDprev_error = 0;
float PIDeint =0;
bool PIDR_forward = true;

int PID1(float kp, float ki, float kd, int error)
{
  PIDc_time= micros();
  delta_time = (PIDc_time - PIDptime)/1000000.0;
  PIDptime = PIDc_time;
  volatile float edot = (error-PIDprev_error)/delta_time;
  PIDeint += error*delta_time;
  volatile int PID= (kp*error) + (kd*edot) + (ki*PIDeint);
  if(PID<0)
    PIDR_forward = false;
  else
    PIDR_forward = true;
  PID = abs(PID);
  Serial.print("  PID#1 ");Serial.print("  Error: ");Serial.print(error);Serial.print("  Derivative term: ");Serial.print(edot);Serial.print("  Integral term: ");Serial.print(PIDeint);Serial.print("  Sum of term: ");Serial.print(PID);Serial.print("  Ticks Difference: ");Serial.println(Right.getticks() - Left.getticks());
  PID = constrain(PID, 0 , 2500);
  if(PID > 2500)
    return Right.getmoving_pwm()+20;
  else
  {
    volatile int PWMB = map(PID, 0,2500,Right.getmoving_pwm(),Right.getmoving_pwm()+20);
    return PWMB;
  }
}

void motion(float dist)
{
  Serial.println("Moving to Given Distance...");
  volatile int limit = ((dist/22.5)*492);
  volatile int error = limit - Right.getticks();
  volatile int diffR = 0;
  volatile int diffL = 0;
  volatile int diff = 0;
  volatile int max_diff = 0;
  volatile int prevticksR = 0;
  volatile int prevticksL = 0;
  volatile int offset = 0;
  volatile int PWMR = 0;

  while(error != 0)
  {
    PWMR = PID1(10,0.01,0.020,error);
    PWML = map(PWMR,Right.getmoving_pwm(),Right.getmoving_pwm()+20,Left.getmoving_pwm(),Left.getmoving_pwm()+20);
    if(PWMR == Right.getmoving_pwm())
    {
      PWMR = 0;
      PWML = 0;
    }
    else
    {
      // diffR = Right.getticks()-prevticksR;
      // diffL = Left.getticks() -prevticksL;
      // prevticksL = Left.getticks();
      // prevticksR = Right.getticks();
      if(diff > max_diff)
      {
        max_diff = diff;
      }
      else
      {
        //do nothing
      }
      //diff = abs(diffR - diffL);
      diff = Right.getticks() - Left.getticks();
      //offset = map(diff,5,max_diff,0,5);
      if(diff > 3)   
      {
        offset = map(abs(diff),5,max_diff,0,3);
        PWML = PWMR + offset;
        PWMR -=offset;
      }
      else if(diff  < -3)
      {
        offset = map(abs(diff),5,max_diff,0,5);
        PWML = PWMR - offset;
        PWMR +=offset;
      }
      else
      {
        //do nothing
      }
    }
    if(PIDR_forward)
      forward(PWML, PWMR);
    else
      backward(PWML, PWMR);
    for(int i=0; i<10;i++)
    {
      //error += (limit - Right.getticks());
      if(Right.getmoving_pwm() < Left.getmoving_pwm())
        error += (limit - Right.getticks());
      else
        error += (limit - Left.getticks());
    }
    error /=10;
  }
  brake();
  for(int i=0; i<10;i++)
  {
  delay(2000);
  Serial.println(limit - Right.getticks());
  }
}

void startingpwm()
{
  Right.setticks(0);
  Left.setticks(0);
  int i= 100;
  //Right motor
  while(i<255)
  {
    forward(0,i);
    delay(50);
    if(Right.getticks() > 5)
    {
      Right.setmoving_pwm(i+10);
      brake();
      delay(500);
      Right.setticks(0);
      Left.setticks(0);
      i=255;
    }
    else
    {
      i++;//wait
    }
  }

  i = 100;

  //Left motor
  while(i<255)
  {
    forward(i,0);
    delay(50);
    if(Left.getticks() > 5)
    {
      Left.setmoving_pwm(i+10);
      brake();
      delay(500);
      Right.setticks(0);
      Left.setticks(0);
      i=255;
    }
    else
    {
      i++;
    }
  }
  brake();
  Serial.print("  Right Motor Started at: ");Serial.println(Right.getmoving_pwm());
  Serial.print("  Left Motor Started at: ");Serial.println(Left.getmoving_pwm());
}
void calibration(bool inp)
{
  delay(500);
  if(inp)
  {
  Serial.println("Calibrating Motors & Gyroscope...");
  startingpwm();
  Serial.println("  Moving PWM Noted.");
  }
  else
    Serial.println("Calibration not allowed.");
  delay(500);
  forward(Left.getmoving_pwm(), Right.getmoving_pwm());
}

// Motors Directions with PWM
void forward(int pwml,int pwmr)
{
  Left.move_forward(pwml);
  Right.move_forward(pwmr);
}
void motor_ticks()
{
  Serial.print("Left Motor: ");
  Serial.print(Left.getticks());
  Serial.print("  Right Motor: ");
  Serial.println(Right.getticks());

}
void backward(int pwml,int pwmr)
{
  Left.move_backward(pwml);
  Right.move_backward(pwmr);
}
void left(int pwml,int pwmr)
{
  Left.move_backward(pwml);
  Right.move_forward(pwmr); 

}
void right(int pwml,int pwmr)
{
  Left.move_forward(pwml);
  Right.move_backward(pwmr);
}
void brake()
{
  Right.donot_move();
  Left.donot_move();
}

//Interrupt Functions for left and right motors

void IRAM_ATTR readEncoderR()
{
  if(digitalRead(ENCR1) > 0)
    Right.tick_increment();
  else
    Right.tick_decrement();
}
void IRAM_ATTR readEncoderL()
{
  if(digitalRead(ENCL1) > 0)
    Left.tick_increment();
  else
    Left.tick_decrement();
}