#ifndef HASEEB_H
#define HASEEB_H

#include<Arduino.h>



extern const int ENCR;// YELLOW
extern const int ENCR1; // GREEN
extern const int ENCL; // YELLOW
extern const int ENCL1; //GREEN

extern const int RM; // pwm right motor
extern const int LM; // pwm left motor

// the number of t he Motor Pins
extern const int RM1; //Right motor 1st terminal
extern const int RM2;  //Right motor 2nd terminal
extern const int LM1; //left motor 1st terminal
extern const int LM2;  //left motor 2nd terminal

//Motor Channel
extern const int RM_ch; //PWM channel--timer based
extern const int LM_ch; //PWM channel--timer based

// setting PWM properties
extern const int motors_freq; //Motor Frequency
extern const int motors_res; //Motor Resoltion 8 bits

class robot_motor
{
private:
    int encoder;// YELLOW-
    int encoder1; // GREEN-
    int pwm_pin; // pwm right motor-
    int pos; //motor 1st terminal-
    int neg;  //motor 2nd terminal-
    int channel; //PWM channel--timer based-
    int ticks = 0;
    int PWM = 0;
    int moving_pwm = 0;
public:
    robot_motor(int M1,int M2,int M,int M_ch,int ENC,int ENC1);
    void setticks(int val){ticks = val;}
    void tick_increment(){ticks++;}
    void tick_decrement(){ticks--;}
    int getticks(){return ticks;}

    void setpwm(int val){PWM = val;}
    int getpwm(){return PWM;}

    void setmoving_pwm(int val){moving_pwm  = val;}
    int getmoving_pwm(){return moving_pwm;}

    int getencoder(){return encoder;}
    int getencoder1(){return encoder1;}
    int getpwm_pin(){return pwm_pin;}
    int getpos(){return pos;}
    int getneg(){return neg;}
    int getchannel(){return channel;}

    void move_forward(int pwm);
    void move_backward(int pwm);
    void donot_move();

};


int PID1(float kp , float ki, float kd, int limit);
int PID2(float kp , float ki, float kd, int diff);
void motion(float dist);
void forward(int pwmr,int pwml);
void backward(int pwmr,int pwml);
void left(int pwmr,int pwml);
void right(int pwmr,int pwml);
void brake();
void readEncoderR();
void readEncoderL();
void debugging();
void getstartingpwm(bool allow = true, int lim = 5);

#endif