#include "haseeb.h"

robot_motor::robot_motor(int M1,int M2,int M,int M_ch,int ENC,int ENC1)
{
    encoder = ENC;// YELLOW-
    encoder1 = ENC1; // GREEN-
    pwm_pin = M; // pwm right motor-
    pos = M1; //motor 1st terminal-
    neg = M2;  //motor 2nd terminal-
    channel = M_ch; //PWM channel--timer based-
}

void robot_motor::move_forward(int pwm)
{
    digitalWrite(pos, HIGH);
    digitalWrite(neg, LOW);
    ledcWrite(channel, pwm);
}

void robot_motor::move_backward(int pwm)
{
    digitalWrite(neg, HIGH);
    digitalWrite(pos, LOW);
    ledcWrite(channel, pwm);
}

void robot_motor::donot_move()
{
    digitalWrite(neg, LOW);
    digitalWrite(pos, LOW);
    ledcWrite(channel, 0);
}


robot_motor Right(RM1,RM2,RM,RM_ch,ENCR,ENCR1);
robot_motor Left(LM1,LM2,LM,LM_ch,ENCL,ENCL1);

int PWMR = 120;
int PWML = 120;
int motor_offset = 1;
int prevticksR = 0;
int prevticksL = 0;
unsigned long timeL = 0;
unsigned long timeR = 0;

double PIDc_time,delta_time,PIDptime;
int PIDprev_error = 0;
float PIDeint =0;
bool PIDL_forward = true;
bool PIDR_forward = true;

int PID1(float kp, float ki, float kd, int limit)
{
  PIDc_time= micros();
  delta_time = (PIDc_time - PIDptime)/1000000.0;
  PIDptime = PIDc_time;

  volatile int error = limit - Right.getticks();
  Serial.print("PID#1 ");
  Serial.print("   Error: ");Serial.print(error);
  volatile float edot = (error-PIDprev_error)/delta_time;
  Serial.print("   Derivative term: ");Serial.print(edot);
  PIDeint += error*delta_time;
  Serial.print("   Integral term: ");Serial.println(PIDeint);
  volatile int PID= (kp*error) + (kd*edot) + (ki*PIDeint);
  if(PID<0)
    PIDR_forward = false;
  else
    PIDR_forward = true;
  PID = abs(PID);
  PID = constrain(PID, 0 , 2500);
  volatile int PWMB = map(PID, 0,2500,100,140);
  PIDprev_error = error;
  return PWMB;
}

void motion(float dist)
{
  volatile int limit = ((dist/22.5)*374);
  volatile int PIDA = PID1(2,0.0005,0.030,limit);
  PWMR = PIDA;
  PWML = PIDA;

  Serial.print("Moving to Goal");
  if(PIDR_forward)
    forward(PWMR, PWML);
  else
    backward(PWMR, PWML);
}

void getstartingpwm(bool allow, int lim)
{
  Right.setticks(0);
  Left.setticks(0);
  int i = 80;
  while(Right.getticks() < 5 && i < 255)
  {
    Right.setmoving_pwm(i);
    forward(Right.getmoving_pwm(), 0);
    i++;
    delay(100);
  }
  brake();
  Serial.print("Right Motor Started at: ");
  Serial.println(Right.getmoving_pwm());
  Right.setticks(0);
  Left.setticks(0);
  delay(2000);
  i = 80;
  while(Left.getticks() < 5 && i < 255)
  {
    Left.setmoving_pwm(i);
    forward(0,Left.getmoving_pwm());
    i++;
    delay(100);
  }
  brake();

  Serial.print("Left Motor Started at: ");
  Serial.println(Left.getmoving_pwm());
  delay(2000);
  // while(1)
  //   forward(Right.getmoving_pwm(), Left.getmoving_pwm());
  Right.setticks(0);
  Left.setticks(0);
  PWML = Left.getmoving_pwm()+10;
  PWMR = Right.getmoving_pwm()+10;
}
void debugging()
{
  volatile int diffR = Right.getticks()-prevticksR;
  volatile int diffL = Left.getticks() -prevticksL;
  prevticksL = Left.getticks();
  prevticksR = Right.getticks();
  if(diffR > diffL)   
  {
    PWMR -= 2;
    PWML += 2;
  }
  else if(diffL > diffR)
  {
    PWMR += 2;
    PWML -= 2; 
  }
  else
  {
    //do nothing
  }
  PWML = constrain(PWML, Left.getmoving_pwm(),Left.getmoving_pwm()+20);
  PWMR = constrain(PWMR, Right.getmoving_pwm(),Right.getmoving_pwm()+20);
  forward(PWMR, PWML);
  /*Serial.print(PWMR);
  Serial.print(",");
  Serial.print(PWML);
  Serial.print(" <-> ");
  Serial.print(Right.getticks());
  Serial.print(",");
  Serial.print(Left.getticks());
  Serial.print("  => ");
  Serial.println(Right.getticks()-Left.getticks());*/
}

// Motors Directions with PWM
void forward(int pwmr,int pwml)
{
  Right.move_forward(pwmr);
  Left.move_forward(pwml);
}
void backward(int pwmr,int pwml)
{
  Right.move_backward(pwmr);
  Left.move_backward(pwml);
}
void left(int pwmr,int pwml)
{
  Right.move_forward(pwmr); 
  Left.move_backward(pwml);
}
void right(int pwmr,int pwml)
{
  Right.move_backward(pwmr);
  Left.move_forward(pwml);
}
void brake()
{
  Right.donot_move();
  Left.donot_move();
}

//Interrupt Functions for left and right motors
void readEncoderR()
{
  if(digitalRead(ENCR1) > 0)
    Right.tick_increment();
  else
    Right.tick_decrement();
}
void readEncoderL()
{
  if(digitalRead(ENCL1) > 0)
    Left.tick_increment();
  else
    Left.tick_decrement();
}