#include "swarm_arena.h"

int** getmap()
{
  Serial.print("Generating Ones map ");
  delay(20);
  Serial.print(".");
  delay(20);
  Serial.print(".");
  delay(20);
  Serial.println(".");
  int** arr = new int*[ROW];
  for (int i = 0; i < ROW; ++i) {
    arr[i] = new int[COL];
    for (int j = 0; j < COL; ++j) {
      arr[i][j] = 1;
    }
  }
  Serial.println("Map of Ones Created Successfully");
  return arr;
}

obstacle::obstacle(int x_cord,int y_cord)
{
  if((x_cord >0) && (x_cord <COL) && (y_cord >0) && (y_cord <ROW))
  {
    pos_x = x_cord;
    pos_y = y_cord;
  }
  else
  Serial.println("Can't add obstacle outside Map. Please check");
}

int** obstacle::draw_obstacle_and_boundary(int** arr2)
{
  for(int j=pos_y-2;j<=pos_y+2;++j)
  {
    for(int k=pos_x-2;k<=pos_x+2;++k)
    {
      if(( j >= 0) && ( j <= ROW-1) && ( k >= 0) && ( k <= COL-1))
        if((j==pos_y-2)||(j==pos_y+2)||(k==pos_x-2)||(k==pos_x+2) )
            arr2[j][k]=2;
        else
            arr2[j][k]=0;
      else
         Serial.println("Encountered boundary outside map. Skipping");  
    }
  } 
return arr2;
}

// function to display array
void printmap(int** arr)
{
  for (int i = ROW-1; i >=0; --i) {
    for (int j = 0; j < COL; ++j) {
      Serial.print(arr[i][j]);
      if(j < COL-1)
        Serial.print(" ");
    }
      Serial.println();
  }
}

//create obstacle and generate its boundary
int** place_obstacle(int** arr1,int posi_x,int posi_y)
{
  obstacle obj(posi_x,posi_y);
  arr1 = obj.draw_obstacle_and_boundary(arr1);
  return arr1;
}

int** our_obstacles(int** arr3)
{
  arr3 = place_obstacle(arr3,5,4);
  arr3 = place_obstacle(arr3,26,11);
  arr3 = place_obstacle(arr3,49,5);
  arr3 = place_obstacle(arr3,70,3);
  return arr3;
}
