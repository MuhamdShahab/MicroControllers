#ifndef SWARM_ARENA_H
#define SWARM_ARENA_H
#include <Arduino.h>

extern const int COL; //total length/box length
extern const int ROW; //total height/box height


int** getmap();


//static and Robots obstacles
class obstacle
{
  private:
    int pos_x = -10;
    int pos_y = -10;
  public:
    obstacle(int x_cord,int y_cord);
    int** draw_obstacle_and_boundary(int** arr2);
};

void printmap(int** arr);
int** place_obstacle(int** arr1,int posi_x,int posi_y);
int** our_obstacles(int** arr3);




#endif
